import { useState } from 'react';
import { AppProvider, useApp } from './store';
import { AppSection } from './types';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import KpiSection from './sections/KpiSection';
import NearMissSection from './sections/NearMissSection';
import StopWorkSection from './sections/StopWorkSection';
import CompetencySection from './sections/CompetencySection';
import AdminPanel from './sections/AdminPanel';

function MainContent() {
  const { state } = useApp();
  const [activeSection, setActiveSection] = useState<AppSection>('dashboard');

  function renderSection() {
    switch (activeSection) {
      case 'dashboard':
        return <Dashboard />;
      case 'kpi':
        return <KpiSection />;
      case 'nearmiss':
        return <NearMissSection />;
      case 'stopwork':
        return <StopWorkSection />;
      case 'competency':
        return <CompetencySection />;
      case 'admin':
        return <AdminPanel />;
      default:
        return <Dashboard />;
    }
  }

  const sectionTitles: Record<AppSection, string> = {
    dashboard: 'Dashboard',
    kpi: 'HSE KPIs',
    nearmiss: 'Near Misses',
    stopwork: 'Stop Work Authority',
    competency: 'Worker Competencies',
    admin: 'Admin Control',
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Sidebar
        activeSection={activeSection}
        onNavigate={setActiveSection}
        isAdmin={state.isAdmin}
      />

      {/* Main content area */}
      <main className="ml-64 min-h-screen">
        {/* Top bar */}
        <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/80 backdrop-blur-lg">
          <div className="flex items-center justify-between px-8 py-4">
            <div>
              <h2 className="text-lg font-semibold text-slate-900">
                {sectionTitles[activeSection]}
              </h2>
            </div>
            <div className="flex items-center gap-3">
              {state.isAdmin && (
                <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold text-emerald-700">
                  ADMIN MODE
                </span>
              )}
              <div className="flex items-center gap-2 rounded-lg bg-slate-100 px-3 py-1.5 text-xs text-slate-600">
                <span className="h-2 w-2 rounded-full bg-emerald-500" />
                All Changes Saved Locally
              </div>
            </div>
          </div>
        </header>

        {/* Page content */}
        <div className="px-8 py-6">{renderSection()}</div>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
