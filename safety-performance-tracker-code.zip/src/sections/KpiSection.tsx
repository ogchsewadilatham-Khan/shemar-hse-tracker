import { useState } from 'react';
import { useApp } from '../store';
import { KpiRecord } from '../types';
import Modal from '../components/Modal';
import { Plus, Edit3, Trash2, BarChart3 } from 'lucide-react';

const emptyForm = (): Omit<KpiRecord, 'id' | 'createdAt'> => ({
  date: new Date().toISOString().split('T')[0],
  category: 'Safety',
  indicator: '',
  value: 0,
  target: 100,
  unit: '%',
  notes: '',
});

export default function KpiSection() {
  const { state, dispatch } = useApp();
  const { kpiRecords, isAdmin } = state;

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm());
  const [filter, setFilter] = useState<'All' | 'Safety' | 'Health' | 'Environment'>('All');

  const filtered = filter === 'All' ? kpiRecords : kpiRecords.filter((k) => k.category === filter);

  function openCreate() {
    setForm(emptyForm());
    setEditingId(null);
    setShowForm(true);
  }

  function openEdit(record: KpiRecord) {
    setForm({
      date: record.date,
      category: record.category,
      indicator: record.indicator,
      value: record.value,
      target: record.target,
      unit: record.unit,
      notes: record.notes,
    });
    setEditingId(record.id);
    setShowForm(true);
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (editingId) {
      dispatch({ type: 'EDIT_KPI', payload: { ...form, id: editingId, createdAt: kpiRecords.find((r) => r.id === editingId)!.createdAt } });
    } else {
      dispatch({
        type: 'ADD_KPI',
        payload: { ...form, id: crypto.randomUUID(), createdAt: new Date().toISOString() },
      });
    }
    setShowForm(false);
  }

  function handleDelete(id: string) {
    if (confirm('Are you sure you want to delete this KPI record?')) {
      dispatch({ type: 'DELETE_KPI', payload: id });
    }
  }

  const catColors: Record<string, string> = {
    Safety: 'bg-blue-50 text-blue-700 border-blue-200',
    Health: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    Environment: 'bg-amber-50 text-amber-700 border-amber-200',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900">HSE KPIs</h2>
          <p className="mt-1 text-sm text-slate-500">Track and monitor key performance indicators</p>
        </div>
        <button
          onClick={openCreate}
          className="flex items-center gap-2 rounded-lg bg-emerald-500 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition-all hover:bg-emerald-600"
        >
          <Plus size={18} />
          New KPI
        </button>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2">
        {(['All', 'Safety', 'Health', 'Environment'] as const).map((cat) => (
          <button
            key={cat}
            onClick={() => setFilter(cat)}
            className={`rounded-lg px-4 py-1.5 text-sm font-medium transition-all ${
              filter === cat
                ? 'bg-emerald-500 text-white shadow-sm'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
        {filtered.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50">
                  <th className="px-4 py-3 font-semibold text-slate-600">Date</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Category</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Indicator</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Value</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Target</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Achievement</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Notes</th>
                  {isAdmin && <th className="px-4 py-3 font-semibold text-slate-600">Actions</th>}
                </tr>
              </thead>
              <tbody>
                {filtered.map((kpi) => {
                  const pct = kpi.target > 0 ? ((kpi.value / kpi.target) * 100).toFixed(1) : '0';
                  return (
                    <tr key={kpi.id} className="border-b border-slate-50 transition-colors hover:bg-slate-50">
                      <td className="px-4 py-3 text-slate-700">{kpi.date}</td>
                      <td className="px-4 py-3">
                        <span
                          className={`inline-block rounded-full border px-2.5 py-0.5 text-xs font-medium ${catColors[kpi.category]}`}
                        >
                          {kpi.category}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-medium text-slate-900">{kpi.indicator}</td>
                      <td className="px-4 py-3 text-slate-700">
                        {kpi.value} {kpi.unit}
                      </td>
                      <td className="px-4 py-3 text-slate-700">
                        {kpi.target} {kpi.unit}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="h-2 w-20 rounded-full bg-slate-100">
                            <div
                              className={`h-2 rounded-full ${
                                Number(pct) >= 90
                                  ? 'bg-emerald-500'
                                  : Number(pct) >= 70
                                    ? 'bg-amber-500'
                                    : 'bg-rose-500'
                              }`}
                              style={{ width: `${Math.min(Number(pct), 100)}%` }}
                            />
                          </div>
                          <span className="text-xs font-medium text-slate-600">{pct}%</span>
                        </div>
                      </td>
                      <td className="max-w-[200px] truncate px-4 py-3 text-slate-500">
                        {kpi.notes || '-'}
                      </td>
                      {isAdmin && (
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => openEdit(kpi)}
                              className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-slate-100 hover:text-blue-600"
                            >
                              <Edit3 size={16} />
                            </button>
                            <button
                              onClick={() => handleDelete(kpi.id)}
                              className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <BarChart3 size={48} className="mb-3 text-slate-300" />
            <p className="text-sm font-medium text-slate-400">No KPI records found</p>
            <p className="text-xs text-slate-300">Create your first KPI to start tracking</p>
          </div>
        )}
      </div>

      {/* Form Modal */}
      <Modal
        isOpen={showForm}
        onClose={() => setShowForm(false)}
        title={editingId ? 'Edit KPI Record' : 'New KPI Record'}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Date
              </label>
              <input
                type="date"
                required
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm text-slate-900 focus:border-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-100"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Category
              </label>
              <select
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value as any })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm text-slate-900 focus:border-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-100"
              >
                <option value="Safety">Safety</option>
                <option value="Health">Health</option>
                <option value="Environment">Environment</option>
              </select>
            </div>
          </div>

          <div>
            <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
              Indicator Name
            </label>
            <input
              type="text"
              required
              placeholder="e.g., Lost Time Injury Rate"
              value={form.indicator}
              onChange={(e) => setForm({ ...form, indicator: e.target.value })}
              className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm text-slate-900 focus:border-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-100"
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Value
              </label>
              <input
                type="number"
                step="0.01"
                required
                value={form.value}
                onChange={(e) => setForm({ ...form, value: Number(e.target.value) })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm text-slate-900 focus:border-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-100"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Target
              </label>
              <input
                type="number"
                step="0.01"
                required
                value={form.target}
                onChange={(e) => setForm({ ...form, target: Number(e.target.value) })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm text-slate-900 focus:border-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-100"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Unit
              </label>
              <input
                type="text"
                required
                placeholder="%, count, rate"
                value={form.unit}
                onChange={(e) => setForm({ ...form, unit: e.target.value })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm text-slate-900 focus:border-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-100"
              />
            </div>
          </div>

          <div>
            <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
              Notes
            </label>
            <textarea
              rows={3}
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm text-slate-900 focus:border-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-100"
            />
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-600 transition-colors hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-lg bg-emerald-500 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-emerald-600"
            >
              {editingId ? 'Update' : 'Create'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
