import { useState } from 'react';
import { useApp } from '../store';
import { NearMiss } from '../types';
import Modal from '../components/Modal';
import { Plus, Edit3, Trash2, AlertTriangle } from 'lucide-react';

const emptyForm = (): Omit<NearMiss, 'id' | 'createdAt'> => ({
  date: new Date().toISOString().split('T')[0],
  location: '',
  description: '',
  reportedBy: '',
  department: '',
  severity: 'Medium',
  status: 'Open',
  correctiveAction: '',
});

export default function NearMissSection() {
  const { state, dispatch } = useApp();
  const { nearMisses, isAdmin } = state;

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm());
  const [filter, setFilter] = useState<'All' | 'Open' | 'Investigation' | 'Closed'>('All');

  const filtered = filter === 'All' ? nearMisses : nearMisses.filter((n) => n.status === filter);

  function openCreate() {
    setForm(emptyForm());
    setEditingId(null);
    setShowForm(true);
  }

  function openEdit(record: NearMiss) {
    setForm({
      date: record.date,
      location: record.location,
      description: record.description,
      reportedBy: record.reportedBy,
      department: record.department,
      severity: record.severity,
      status: record.status,
      correctiveAction: record.correctiveAction,
    });
    setEditingId(record.id);
    setShowForm(true);
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (editingId) {
      dispatch({
        type: 'EDIT_NEAR_MISS',
        payload: { ...form, id: editingId, createdAt: nearMisses.find((r) => r.id === editingId)!.createdAt },
      });
    } else {
      dispatch({
        type: 'ADD_NEAR_MISS',
        payload: { ...form, id: crypto.randomUUID(), createdAt: new Date().toISOString() },
      });
    }
    setShowForm(false);
  }

  function handleDelete(id: string) {
    if (confirm('Are you sure you want to delete this Near Miss record?')) {
      dispatch({ type: 'DELETE_NEAR_MISS', payload: id });
    }
  }

  const severityColors: Record<string, string> = {
    Low: 'bg-slate-100 text-slate-600',
    Medium: 'bg-amber-50 text-amber-600',
    High: 'bg-orange-50 text-orange-600',
    Critical: 'bg-rose-50 text-rose-600',
  };

  const statusColors: Record<string, string> = {
    Open: 'bg-red-50 text-red-600 border-red-200',
    Investigation: 'bg-amber-50 text-amber-600 border-amber-200',
    Closed: 'bg-emerald-50 text-emerald-600 border-emerald-200',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900">Near Misses</h2>
          <p className="mt-1 text-sm text-slate-500">Report and track near miss incidents</p>
        </div>
        <button
          onClick={openCreate}
          className="flex items-center gap-2 rounded-lg bg-amber-500 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition-all hover:bg-amber-600"
        >
          <Plus size={18} />
          Report Near Miss
        </button>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2">
        {(['All', 'Open', 'Investigation', 'Closed'] as const).map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`rounded-lg px-4 py-1.5 text-sm font-medium transition-all ${
              filter === s
                ? 'bg-amber-500 text-white shadow-sm'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
        {filtered.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50">
                  <th className="px-4 py-3 font-semibold text-slate-600">Date</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Location</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Description</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Reported By</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Department</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Severity</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Status</th>
                  {isAdmin && <th className="px-4 py-3 font-semibold text-slate-600">Actions</th>}
                </tr>
              </thead>
              <tbody>
                {filtered.map((nm) => (
                  <tr key={nm.id} className="border-b border-slate-50 transition-colors hover:bg-slate-50">
                    <td className="px-4 py-3 text-slate-700">{nm.date}</td>
                    <td className="px-4 py-3 text-slate-700">{nm.location}</td>
                    <td className="max-w-[250px] truncate px-4 py-3 text-slate-700">
                      {nm.description}
                    </td>
                    <td className="px-4 py-3 text-slate-700">{nm.reportedBy}</td>
                    <td className="px-4 py-3 text-slate-700">{nm.department}</td>
                    <td className="px-4 py-3">
                      <span
                        className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${severityColors[nm.severity]}`}
                      >
                        {nm.severity}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-block rounded-full border px-2.5 py-0.5 text-xs font-medium ${statusColors[nm.status]}`}
                      >
                        {nm.status}
                      </span>
                    </td>
                    {isAdmin && (
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => openEdit(nm)}
                            className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-slate-100 hover:text-blue-600"
                          >
                            <Edit3 size={16} />
                          </button>
                          <button
                            onClick={() => handleDelete(nm.id)}
                            className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <AlertTriangle size={48} className="mb-3 text-slate-300" />
            <p className="text-sm font-medium text-slate-400">No near miss reports</p>
            <p className="text-xs text-slate-300">Report a near miss to keep track</p>
          </div>
        )}
      </div>

      {/* Form Modal */}
      <Modal
        isOpen={showForm}
        onClose={() => setShowForm(false)}
        title={editingId ? 'Edit Near Miss' : 'Report Near Miss'}
        size="lg"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Date
              </label>
              <input
                type="date"
                required
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-amber-400 focus:outline-none focus:ring-2 focus:ring-amber-100"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Location
              </label>
              <input
                type="text"
                required
                placeholder="e.g., Building A, Floor 3"
                value={form.location}
                onChange={(e) => setForm({ ...form, location: e.target.value })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-amber-400 focus:outline-none focus:ring-2 focus:ring-amber-100"
              />
            </div>
          </div>

          <div>
            <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
              Description
            </label>
            <textarea
              rows={3}
              required
              placeholder="Describe what happened..."
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-amber-400 focus:outline-none focus:ring-2 focus:ring-amber-100"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Reported By
              </label>
              <input
                type="text"
                required
                placeholder="Full name"
                value={form.reportedBy}
                onChange={(e) => setForm({ ...form, reportedBy: e.target.value })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-amber-400 focus:outline-none focus:ring-2 focus:ring-amber-100"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Department
              </label>
              <input
                type="text"
                required
                placeholder="e.g., Operations"
                value={form.department}
                onChange={(e) => setForm({ ...form, department: e.target.value })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-amber-400 focus:outline-none focus:ring-2 focus:ring-amber-100"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Severity
              </label>
              <select
                value={form.severity}
                onChange={(e) => setForm({ ...form, severity: e.target.value as any })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-amber-400 focus:outline-none focus:ring-2 focus:ring-amber-100"
              >
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
                <option value="Critical">Critical</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Status
              </label>
              <select
                value={form.status}
                onChange={(e) => setForm({ ...form, status: e.target.value as any })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-amber-400 focus:outline-none focus:ring-2 focus:ring-amber-100"
              >
                <option value="Open">Open</option>
                <option value="Investigation">Investigation</option>
                <option value="Closed">Closed</option>
              </select>
            </div>
          </div>

          <div>
            <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
              Corrective Action
            </label>
            <textarea
              rows={2}
              value={form.correctiveAction}
              onChange={(e) => setForm({ ...form, correctiveAction: e.target.value })}
              placeholder="Actions taken to prevent recurrence"
              className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-amber-400 focus:outline-none focus:ring-2 focus:ring-amber-100"
            />
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-600 transition-colors hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-lg bg-amber-500 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-amber-600"
            >
              {editingId ? 'Update' : 'Submit'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
