import { useApp } from '../store';
import StatCard from './StatCard';
import { BarChart3, AlertTriangle, ShieldAlert, GraduationCap, Activity } from 'lucide-react';

export default function Dashboard() {
  const { state } = useApp();
  const { kpiRecords, nearMisses, stopWorkAuthorities, workerCompetencies } = state;

  const totalKpis = kpiRecords.length;
  const avgKpiValue =
    totalKpis > 0
      ? (kpiRecords.reduce((sum, k) => sum + (k.value / k.target) * 100, 0) / totalKpis).toFixed(1)
      : '0';

  const openNearMisses = nearMisses.filter((n) => n.status !== 'Closed').length;
  const highSeverityNearMisses = nearMisses.filter((n) => n.severity === 'High' || n.severity === 'Critical').length;

  const activeSWA = stopWorkAuthorities.filter((s) => s.status === 'Active').length;
  const resolvedSWA = stopWorkAuthorities.filter((s) => s.status === 'Resolved' || s.status === 'Reviewed').length;

  const validCompetencies = workerCompetencies.filter((c) => c.status === 'Valid').length;
  const expiringCompetencies = workerCompetencies.filter((c) => c.status === 'Expiring Soon').length;

  const totalRecords =
    totalKpis + nearMisses.length + stopWorkAuthorities.length + workerCompetencies.length;

  const recentItems = [
    ...kpiRecords.map((r) => ({ ...r, type: 'KPI' as const })),
    ...nearMisses.map((r) => ({ ...r, type: 'Near Miss' as const })),
    ...stopWorkAuthorities.map((r) => ({ ...r, type: 'Stop Work' as const })),
    ...workerCompetencies.map((r) => ({ ...r, type: 'Competency' as const })),
  ]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 8);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-slate-900">Dashboard</h2>
        <p className="mt-1 text-sm text-slate-500">
          Real-time overview of your HSE performance metrics
        </p>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
        <StatCard
          title="Total Records"
          value={totalRecords}
          icon={<Activity size={22} />}
          color="emerald"
          subtitle="Across all modules"
        />
        <StatCard
          title="KPI Achievement"
          value={`${avgKpiValue}%`}
          icon={<BarChart3 size={22} />}
          color="blue"
          subtitle={`${totalKpis} indicators tracked`}
          trend={totalKpis > 0 ? { value: 5, isPositive: true } : undefined}
        />
        <StatCard
          title="Open Near Misses"
          value={openNearMisses}
          icon={<AlertTriangle size={22} />}
          color="amber"
          subtitle={`${highSeverityNearMisses} high/critical severity`}
          trend={openNearMisses > 0 ? { value: 12, isPositive: false } : undefined}
        />
        <StatCard
          title="Stop Work Actions"
          value={`${activeSWA} Active`}
          icon={<ShieldAlert size={22} />}
          color="rose"
          subtitle={`${resolvedSWA} resolved`}
        />
        <StatCard
          title="Valid Competencies"
          value={validCompetencies}
          icon={<GraduationCap size={22} />}
          color="violet"
          subtitle={`${expiringCompetencies} expiring soon`}
          trend={expiringCompetencies > 0 ? { value: expiringCompetencies, isPositive: false } : undefined}
        />
      </div>

      {/* KPI Overview */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <h3 className="mb-3 text-sm font-semibold uppercase tracking-wider text-slate-500">
            KPI Performance by Category
          </h3>
          <div className="space-y-4">
            {(['Safety', 'Health', 'Environment'] as const).map((cat) => {
              const catRecords = kpiRecords.filter((k) => k.category === cat);
              const avg =
                catRecords.length > 0
                  ? catRecords.reduce((s, k) => s + (k.value / k.target) * 100, 0) / catRecords.length
                  : 0;
              const color =
                avg >= 90
                  ? 'bg-emerald-500'
                  : avg >= 70
                    ? 'bg-amber-500'
                    : 'bg-rose-500';
              const icon =
                cat === 'Safety'
                  ? '🛡️'
                  : cat === 'Health'
                    ? '❤️'
                    : '🌿';
              return (
                <div key={cat}>
                  <div className="mb-1.5 flex items-center justify-between text-sm">
                    <span className="font-medium text-slate-700">
                      {icon} {cat}
                    </span>
                    <span className="font-semibold text-slate-900">{avg.toFixed(1)}%</span>
                  </div>
                  <div className="h-2.5 rounded-full bg-slate-100">
                    <div
                      className={`h-2.5 rounded-full transition-all duration-500 ${color}`}
                      style={{ width: `${Math.min(avg, 100)}%` }}
                    />
                  </div>
                  <p className="mt-0.5 text-xs text-slate-400">{catRecords.length} records</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <h3 className="mb-3 text-sm font-semibold uppercase tracking-wider text-slate-500">
            Recent Activity
          </h3>
          {recentItems.length > 0 ? (
            <div className="space-y-3">
              {recentItems.map((item: any, idx: number) => (
                <div key={idx} className="flex items-start gap-3 border-b border-slate-50 pb-3 last:border-0 last:pb-0">
                  <div
                    className={`mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-xs ${
                      item.type === 'KPI'
                        ? 'bg-blue-50 text-blue-600'
                        : item.type === 'Near Miss'
                          ? 'bg-amber-50 text-amber-600'
                          : item.type === 'Stop Work'
                            ? 'bg-rose-50 text-rose-600'
                            : 'bg-violet-50 text-violet-600'
                    }`}
                  >
                    {item.type === 'KPI'
                      ? '📊'
                      : item.type === 'Near Miss'
                        ? '⚠️'
                        : item.type === 'Stop Work'
                          ? '🛑'
                          : '🎓'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="truncate text-sm font-medium text-slate-900">
                      {'indicator' in item
                        ? item.indicator
                        : 'description' in item
                          ? item.description
                          : 'name' in item
                            ? item.name
                            : item.reason}
                    </p>
                    <p className="text-xs text-slate-400">
                      {item.type} · {new Date(item.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-10 text-center">
              <Activity size={40} className="mb-3 text-slate-300" />
              <p className="text-sm font-medium text-slate-400">No activity yet</p>
              <p className="text-xs text-slate-300">Start adding records to see activity here</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
