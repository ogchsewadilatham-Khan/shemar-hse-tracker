export interface KpiRecord {
  id: string;
  date: string;
  category: 'Safety' | 'Health' | 'Environment';
  indicator: string;
  value: number;
  target: number;
  unit: string;
  notes: string;
  createdAt: string;
}

export interface NearMiss {
  id: string;
  date: string;
  location: string;
  description: string;
  reportedBy: string;
  department: string;
  severity: 'Low' | 'Medium' | 'High' | 'Critical';
  status: 'Open' | 'Investigation' | 'Closed';
  correctiveAction: string;
  createdAt: string;
}

export interface StopWorkAuthority {
  id: string;
  date: string;
  initiatedBy: string;
  location: string;
  reason: string;
  description: string;
  department: string;
  status: 'Active' | 'Resolved' | 'Reviewed';
  resolvedDate: string;
  resolution: string;
  createdAt: string;
}

export interface WorkerCompetency {
  id: string;
  name: string;
  employeeId: string;
  department: string;
  role: string;
  certification: string;
  expiryDate: string;
  status: 'Valid' | 'Expiring Soon' | 'Expired';
  lastAssessmentDate: string;
  notes: string;
  createdAt: string;
}

export type AppSection = 'dashboard' | 'kpi' | 'nearmiss' | 'stopwork' | 'competency' | 'admin';
