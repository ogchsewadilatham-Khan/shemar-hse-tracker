import { useState } from 'react';
import { useApp } from '../store';
import { WorkerCompetency } from '../types';
import Modal from '../components/Modal';
import { Plus, Edit3, Trash2, GraduationCap } from 'lucide-react';

const emptyForm = (): Omit<WorkerCompetency, 'id' | 'createdAt'> => ({
  name: '',
  employeeId: '',
  department: '',
  role: '',
  certification: '',
  expiryDate: '',
  status: 'Valid',
  lastAssessmentDate: new Date().toISOString().split('T')[0],
  notes: '',
});

export default function CompetencySection() {
  const { state, dispatch } = useApp();
  const { workerCompetencies, isAdmin } = state;

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm());
  const [filter, setFilter] = useState<'All' | 'Valid' | 'Expiring Soon' | 'Expired'>('All');

  const filtered =
    filter === 'All'
      ? workerCompetencies
      : workerCompetencies.filter((c) => c.status === filter);

  function openCreate() {
    setForm(emptyForm());
    setEditingId(null);
    setShowForm(true);
  }

  function openEdit(record: WorkerCompetency) {
    setForm({
      name: record.name,
      employeeId: record.employeeId,
      department: record.department,
      role: record.role,
      certification: record.certification,
      expiryDate: record.expiryDate,
      status: record.status,
      lastAssessmentDate: record.lastAssessmentDate,
      notes: record.notes,
    });
    setEditingId(record.id);
    setShowForm(true);
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (editingId) {
      dispatch({
        type: 'EDIT_COMPETENCY',
        payload: {
          ...form,
          id: editingId,
          createdAt: workerCompetencies.find((r) => r.id === editingId)!.createdAt,
        },
      });
    } else {
      dispatch({
        type: 'ADD_COMPETENCY',
        payload: { ...form, id: crypto.randomUUID(), createdAt: new Date().toISOString() },
      });
    }
    setShowForm(false);
  }

  function handleDelete(id: string) {
    if (confirm('Are you sure you want to delete this competency record?')) {
      dispatch({ type: 'DELETE_COMPETENCY', payload: id });
    }
  }

  const statusColors: Record<string, string> = {
    Valid: 'bg-emerald-50 text-emerald-600 border-emerald-200',
    'Expiring Soon': 'bg-amber-50 text-amber-600 border-amber-200',
    Expired: 'bg-rose-50 text-rose-600 border-rose-200',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900">Worker Competencies</h2>
          <p className="mt-1 text-sm text-slate-500">
            Track certifications and competency assessments
          </p>
        </div>
        <button
          onClick={openCreate}
          className="flex items-center gap-2 rounded-lg bg-violet-500 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition-all hover:bg-violet-600"
        >
          <Plus size={18} />
          Add Competency
        </button>
      </div>

      <div className="flex gap-2">
        {(['All', 'Valid', 'Expiring Soon', 'Expired'] as const).map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`rounded-lg px-4 py-1.5 text-sm font-medium transition-all ${
              filter === s
                ? 'bg-violet-500 text-white shadow-sm'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
        {filtered.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50">
                  <th className="px-4 py-3 font-semibold text-slate-600">Name</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Employee ID</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Department</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Role</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Certification</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Expiry</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Status</th>
                  {isAdmin && <th className="px-4 py-3 font-semibold text-slate-600">Actions</th>}
                </tr>
              </thead>
              <tbody>
                {filtered.map((comp) => (
                  <tr key={comp.id} className="border-b border-slate-50 transition-colors hover:bg-slate-50">
                    <td className="px-4 py-3 font-medium text-slate-900">{comp.name}</td>
                    <td className="px-4 py-3 text-slate-700">{comp.employeeId}</td>
                    <td className="px-4 py-3 text-slate-700">{comp.department}</td>
                    <td className="px-4 py-3 text-slate-700">{comp.role}</td>
                    <td className="px-4 py-3 text-slate-700">{comp.certification}</td>
                    <td className="px-4 py-3 text-slate-700">{comp.expiryDate}</td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-block rounded-full border px-2.5 py-0.5 text-xs font-medium ${statusColors[comp.status]}`}
                      >
                        {comp.status}
                      </span>
                    </td>
                    {isAdmin && (
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => openEdit(comp)}
                            className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-slate-100 hover:text-blue-600"
                          >
                            <Edit3 size={16} />
                          </button>
                          <button
                            onClick={() => handleDelete(comp.id)}
                            className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <GraduationCap size={48} className="mb-3 text-slate-300" />
            <p className="text-sm font-medium text-slate-400">No competency records</p>
            <p className="text-xs text-slate-300">Add worker competencies to get started</p>
          </div>
        )}
      </div>

      {/* Form Modal */}
      <Modal
        isOpen={showForm}
        onClose={() => setShowForm(false)}
        title={editingId ? 'Edit Competency' : 'Add Competency Record'}
        size="lg"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Full Name
              </label>
              <input
                type="text"
                required
                placeholder="Worker's full name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-violet-400 focus:outline-none focus:ring-2 focus:ring-violet-100"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Employee ID
              </label>
              <input
                type="text"
                required
                placeholder="EMP-001"
                value={form.employeeId}
                onChange={(e) => setForm({ ...form, employeeId: e.target.value })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-violet-400 focus:outline-none focus:ring-2 focus:ring-violet-100"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Department
              </label>
              <input
                type="text"
                required
                placeholder="e.g., Electrical"
                value={form.department}
                onChange={(e) => setForm({ ...form, department: e.target.value })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-violet-400 focus:outline-none focus:ring-2 focus:ring-violet-100"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Role / Position
              </label>
              <input
                type="text"
                required
                placeholder="e.g., Electrician"
                value={form.role}
                onChange={(e) => setForm({ ...form, role: e.target.value })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-violet-400 focus:outline-none focus:ring-2 focus:ring-violet-100"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Certification
              </label>
              <input
                type="text"
                required
                placeholder="e.g., Confined Space Entry"
                value={form.certification}
                onChange={(e) => setForm({ ...form, certification: e.target.value })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-violet-400 focus:outline-none focus:ring-2 focus:ring-violet-100"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Expiry Date
              </label>
              <input
                type="date"
                required
                value={form.expiryDate}
                onChange={(e) => setForm({ ...form, expiryDate: e.target.value })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-violet-400 focus:outline-none focus:ring-2 focus:ring-violet-100"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Status
              </label>
              <select
                value={form.status}
                onChange={(e) => setForm({ ...form, status: e.target.value as any })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-violet-400 focus:outline-none focus:ring-2 focus:ring-violet-100"
              >
                <option value="Valid">Valid</option>
                <option value="Expiring Soon">Expiring Soon</option>
                <option value="Expired">Expired</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Last Assessment Date
              </label>
              <input
                type="date"
                required
                value={form.lastAssessmentDate}
                onChange={(e) => setForm({ ...form, lastAssessmentDate: e.target.value })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-violet-400 focus:outline-none focus:ring-2 focus:ring-violet-100"
              />
            </div>
          </div>

          <div>
            <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
              Notes
            </label>
            <textarea
              rows={2}
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              placeholder="Additional comments"
              className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-violet-400 focus:outline-none focus:ring-2 focus:ring-violet-100"
            />
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-600 transition-colors hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-lg bg-violet-500 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-violet-600"
            >
              {editingId ? 'Update' : 'Add'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
