import { AppSection } from '../types';
import {
  LayoutDashboard,
  BarChart3,
  AlertTriangle,
  ShieldAlert,
  GraduationCap,
  Settings,
  Shield,
} from 'lucide-react';

const navItems: { id: AppSection; label: string; icon: React.ReactNode }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={20} /> },
  { id: 'kpi', label: 'HSE KPIs', icon: <BarChart3 size={20} /> },
  { id: 'nearmiss', label: 'Near Misses', icon: <AlertTriangle size={20} /> },
  { id: 'stopwork', label: 'Stop Work Authority', icon: <ShieldAlert size={20} /> },
  { id: 'competency', label: 'Competencies', icon: <GraduationCap size={20} /> },
  { id: 'admin', label: 'Admin Control', icon: <Settings size={20} /> },
];

interface SidebarProps {
  activeSection: AppSection;
  onNavigate: (section: AppSection) => void;
  isAdmin: boolean;
}

export default function Sidebar({ activeSection, onNavigate, isAdmin }: SidebarProps) {
  return (
    <aside className="fixed left-0 top-0 z-40 flex h-screen w-64 flex-col bg-slate-900 text-white shadow-xl">
      {/* Brand */}
      <div className="flex items-center gap-3 border-b border-slate-700 px-6 py-5">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-500 shadow-lg">
          <Shield size={22} className="text-white" />
        </div>
        <div>
          <h1 className="text-lg font-bold leading-tight tracking-tight">SHEMAR</h1>
          <p className="text-[10px] font-medium uppercase tracking-widest text-emerald-400">
            HSE Tracker
          </p>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            className={`flex w-full items-center gap-3 rounded-lg px-4 py-2.5 text-sm font-medium transition-all duration-200 ${
              activeSection === item.id
                ? 'bg-emerald-500/20 text-emerald-300 shadow-sm'
                : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            {item.icon}
            <span>{item.label}</span>
            {item.id === 'admin' && (
              <span
                className={`ml-auto rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase ${
                  isAdmin ? 'bg-emerald-500/30 text-emerald-300' : 'bg-slate-700 text-slate-400'
                }`}
              >
                {isAdmin ? 'ON' : 'OFF'}
              </span>
            )}
          </button>
        ))}
      </nav>

      {/* Footer */}
      <div className="border-t border-slate-700 px-6 py-4">
        <p className="text-[10px] text-slate-500">
          v2.0.0 · HSE Management System
        </p>
      </div>
    </aside>
  );
}
