import { useState } from 'react';
import { useApp } from '../store';
import {
  Shield,
  BarChart3,
  AlertTriangle,
  ShieldAlert,
  GraduationCap,
  Download,
  Trash2,
  Lock,
  Unlock,
  Database,
  HardDrive,
} from 'lucide-react';

export default function AdminPanel() {
  const { state, dispatch } = useApp();
  const { kpiRecords, nearMisses, stopWorkAuthorities, workerCompetencies, isAdmin } = state;
  const [confirmClear, setConfirmClear] = useState<string | null>(null);

  const totalRecords =
    kpiRecords.length + nearMisses.length + stopWorkAuthorities.length + workerCompetencies.length;

  function exportData() {
    const data = {
      exportDate: new Date().toISOString(),
      app: 'SHEMAR HSE TRACKER',
      kpiRecords,
      nearMisses,
      stopWorkAuthorities,
      workerCompetencies,
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `shemar-hse-export-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function clearAllRecords() {
    if (confirmClear === 'all') {
      kpiRecords.forEach((r) => dispatch({ type: 'DELETE_KPI', payload: r.id }));
      nearMisses.forEach((r) => dispatch({ type: 'DELETE_NEAR_MISS', payload: r.id }));
      stopWorkAuthorities.forEach((r) => dispatch({ type: 'DELETE_STOP_WORK', payload: r.id }));
      workerCompetencies.forEach((r) => dispatch({ type: 'DELETE_COMPETENCY', payload: r.id }));
      setConfirmClear(null);
    }
  }

  const sections = [
    {
      key: 'kpi',
      label: 'HSE KPIs',
      icon: <BarChart3 size={20} />,
      count: kpiRecords.length,
      color: 'blue',
      bgColor: 'bg-blue-50',
      textColor: 'text-blue-600',
      borderColor: 'border-blue-200',
    },
    {
      key: 'nearmiss',
      label: 'Near Misses',
      icon: <AlertTriangle size={20} />,
      count: nearMisses.length,
      color: 'amber',
      bgColor: 'bg-amber-50',
      textColor: 'text-amber-600',
      borderColor: 'border-amber-200',
    },
    {
      key: 'stopwork',
      label: 'Stop Work Authorities',
      icon: <ShieldAlert size={20} />,
      count: stopWorkAuthorities.length,
      color: 'rose',
      bgColor: 'bg-rose-50',
      textColor: 'text-rose-600',
      borderColor: 'border-rose-200',
    },
    {
      key: 'competency',
      label: 'Worker Competencies',
      icon: <GraduationCap size={20} />,
      count: workerCompetencies.length,
      color: 'violet',
      bgColor: 'bg-violet-50',
      textColor: 'text-violet-600',
      borderColor: 'border-violet-200',
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-slate-900">Admin Control Panel</h2>
        <p className="mt-1 text-sm text-slate-500">
          Manage system settings, export data, and control all records
        </p>
      </div>

      {/* Admin Toggle */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className={`rounded-lg p-2.5 ${isAdmin ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}
            >
              {isAdmin ? <Unlock size={22} /> : <Lock size={22} />}
            </div>
            <div>
              <h3 className="font-semibold text-slate-900">
                Admin Mode: {isAdmin ? 'Enabled' : 'Disabled'}
              </h3>
              <p className="text-xs text-slate-500">
                {isAdmin
                  ? 'Edit and delete buttons are visible across all sections'
                  : 'Enable to access edit/delete controls on all records'}
              </p>
            </div>
          </div>
          <button
            onClick={() => dispatch({ type: 'TOGGLE_ADMIN' })}
            className={`rounded-lg px-5 py-2.5 text-sm font-semibold transition-all ${
              isAdmin
                ? 'bg-rose-500 text-white hover:bg-rose-600'
                : 'bg-emerald-500 text-white hover:bg-emerald-600'
            }`}
          >
            {isAdmin ? 'Disable Admin' : 'Enable Admin'}
          </button>
        </div>
      </div>

      {/* System Overview */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {sections.map((section) => (
          <div
            key={section.key}
            className={`rounded-xl border ${section.borderColor} ${section.bgColor} p-4 shadow-sm`}
          >
            <div className="flex items-center justify-between">
              <div className={`${section.textColor}`}>{section.icon}</div>
              <span className="text-2xl font-bold text-slate-900">{section.count}</span>
            </div>
            <p className="mt-2 text-sm font-medium text-slate-700">{section.label}</p>
          </div>
        ))}
      </div>

      {/* System Stats */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
        <h3 className="mb-4 flex items-center gap-2 text-sm font-semibold uppercase tracking-wider text-slate-500">
          <Database size={16} />
          System Statistics
        </h3>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          <div>
            <p className="text-xs text-slate-400">Total Records</p>
            <p className="text-xl font-bold text-slate-900">{totalRecords}</p>
          </div>
          <div>
            <p className="text-xs text-slate-400">KPI Achievement</p>
            <p className="text-xl font-bold text-slate-900">
              {kpiRecords.length > 0
                ? (
                    kpiRecords.reduce((s, k) => s + (k.value / k.target) * 100, 0) /
                    kpiRecords.length
                  ).toFixed(1) + '%'
                : 'N/A'}
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-400">Open SWA</p>
            <p className="text-xl font-bold text-slate-900">
              {stopWorkAuthorities.filter((s) => s.status === 'Active').length}
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-400">Expired Competencies</p>
            <p className="text-xl font-bold text-slate-900">
              {workerCompetencies.filter((c) => c.status === 'Expired').length}
            </p>
          </div>
        </div>
      </div>

      {/* Danger Zone */}
      <div className="rounded-xl border border-red-200 bg-white p-5 shadow-sm">
        <h3 className="mb-4 flex items-center gap-2 text-sm font-semibold uppercase tracking-wider text-rose-600">
          <HardDrive size={16} />
          Danger Zone
        </h3>
        <div className="space-y-4">
          {/* Export */}
          <div className="flex items-center justify-between rounded-lg border border-slate-200 p-4">
            <div>
              <p className="font-medium text-slate-900">Export All Data</p>
              <p className="text-xs text-slate-500">
                Download all records as a JSON backup file
              </p>
            </div>
            <button
              onClick={exportData}
              disabled={totalRecords === 0}
              className="flex items-center gap-2 rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-600 transition-all hover:bg-slate-50 disabled:opacity-50"
            >
              <Download size={16} />
              Export
            </button>
          </div>

          {/* Clear All */}
          <div className="rounded-lg border border-red-200 bg-red-50 p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-red-800">Clear All Records</p>
                <p className="text-xs text-red-600">
                  This action permanently removes ALL data from the system
                </p>
              </div>
              {confirmClear === 'all' ? (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setConfirmClear(null)}
                    className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-600 hover:bg-slate-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={clearAllRecords}
                    className="flex items-center gap-1 rounded-lg bg-red-600 px-3 py-2 text-xs font-semibold text-white hover:bg-red-700"
                  >
                    <Trash2 size={14} />
                    Confirm Delete
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setConfirmClear('all')}
                  disabled={totalRecords === 0}
                  className="flex items-center gap-2 rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white transition-all hover:bg-red-700 disabled:opacity-50"
                >
                  <Trash2 size={16} />
                  Clear All
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Admin Info */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
        <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold uppercase tracking-wider text-slate-500">
          <Shield size={16} />
          About SHEMAR HSE TRACKER
        </h3>
        <div className="space-y-1 text-sm text-slate-600">
          <p>
            <span className="font-medium text-slate-900">Version:</span> 2.0.0
          </p>
          <p>
            <span className="font-medium text-slate-900">Platform:</span> Web · Android · macOS
          </p>
          <p>
            <span className="font-medium text-slate-900">Modules:</span> HSE KPIs · Near Misses ·
            Stop Work Authority · Worker Competencies
          </p>
          <p>
            <span className="font-medium text-slate-900">Admin Control:</span> Full CRUD operations
            on all records with data export
          </p>
        </div>
      </div>
    </div>
  );
}
