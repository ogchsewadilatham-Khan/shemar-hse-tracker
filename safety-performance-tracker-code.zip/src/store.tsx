import { createContext, useContext, useReducer, ReactNode, Dispatch } from 'react';
import { KpiRecord, NearMiss, StopWorkAuthority, WorkerCompetency } from './types';

interface AppState {
  kpiRecords: KpiRecord[];
  nearMisses: NearMiss[];
  stopWorkAuthorities: StopWorkAuthority[];
  workerCompetencies: WorkerCompetency[];
  isAdmin: boolean;
}

type Action =
  | { type: 'ADD_KPI'; payload: KpiRecord }
  | { type: 'EDIT_KPI'; payload: KpiRecord }
  | { type: 'DELETE_KPI'; payload: string }
  | { type: 'ADD_NEAR_MISS'; payload: NearMiss }
  | { type: 'EDIT_NEAR_MISS'; payload: NearMiss }
  | { type: 'DELETE_NEAR_MISS'; payload: string }
  | { type: 'ADD_STOP_WORK'; payload: StopWorkAuthority }
  | { type: 'EDIT_STOP_WORK'; payload: StopWorkAuthority }
  | { type: 'DELETE_STOP_WORK'; payload: string }
  | { type: 'ADD_COMPETENCY'; payload: WorkerCompetency }
  | { type: 'EDIT_COMPETENCY'; payload: WorkerCompetency }
  | { type: 'DELETE_COMPETENCY'; payload: string }
  | { type: 'TOGGLE_ADMIN' };

const initialState: AppState = {
  kpiRecords: [],
  nearMisses: [],
  stopWorkAuthorities: [],
  workerCompetencies: [],
  isAdmin: false,
};

function appReducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'ADD_KPI':
      return { ...state, kpiRecords: [...state.kpiRecords, action.payload] };
    case 'EDIT_KPI':
      return {
        ...state,
        kpiRecords: state.kpiRecords.map((r) => (r.id === action.payload.id ? action.payload : r)),
      };
    case 'DELETE_KPI':
      return { ...state, kpiRecords: state.kpiRecords.filter((r) => r.id !== action.payload) };
    case 'ADD_NEAR_MISS':
      return { ...state, nearMisses: [...state.nearMisses, action.payload] };
    case 'EDIT_NEAR_MISS':
      return {
        ...state,
        nearMisses: state.nearMisses.map((r) => (r.id === action.payload.id ? action.payload : r)),
      };
    case 'DELETE_NEAR_MISS':
      return { ...state, nearMisses: state.nearMisses.filter((r) => r.id !== action.payload) };
    case 'ADD_STOP_WORK':
      return { ...state, stopWorkAuthorities: [...state.stopWorkAuthorities, action.payload] };
    case 'EDIT_STOP_WORK':
      return {
        ...state,
        stopWorkAuthorities: state.stopWorkAuthorities.map((r) =>
          r.id === action.payload.id ? action.payload : r
        ),
      };
    case 'DELETE_STOP_WORK':
      return {
        ...state,
        stopWorkAuthorities: state.stopWorkAuthorities.filter((r) => r.id !== action.payload),
      };
    case 'ADD_COMPETENCY':
      return { ...state, workerCompetencies: [...state.workerCompetencies, action.payload] };
    case 'EDIT_COMPETENCY':
      return {
        ...state,
        workerCompetencies: state.workerCompetencies.map((r) =>
          r.id === action.payload.id ? action.payload : r
        ),
      };
    case 'DELETE_COMPETENCY':
      return {
        ...state,
        workerCompetencies: state.workerCompetencies.filter((r) => r.id !== action.payload),
      };
    case 'TOGGLE_ADMIN':
      return { ...state, isAdmin: !state.isAdmin };
    default:
      return state;
  }
}

const AppContext = createContext<{ state: AppState; dispatch: Dispatch<Action> }>({
  state: initialState,
  dispatch: () => {},
});

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);
  return <AppContext.Provider value={{ state, dispatch }}>{children}</AppContext.Provider>;
}

export function useApp() {
  return useContext(AppContext);
}
