import { useState } from 'react';
import { useApp } from '../store';
import { StopWorkAuthority } from '../types';
import Modal from '../components/Modal';
import { Plus, Edit3, Trash2, ShieldAlert } from 'lucide-react';

const emptyForm = (): Omit<StopWorkAuthority, 'id' | 'createdAt'> => ({
  date: new Date().toISOString().split('T')[0],
  initiatedBy: '',
  location: '',
  reason: '',
  description: '',
  department: '',
  status: 'Active',
  resolvedDate: '',
  resolution: '',
});

export default function StopWorkSection() {
  const { state, dispatch } = useApp();
  const { stopWorkAuthorities, isAdmin } = state;

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm());
  const [filter, setFilter] = useState<'All' | 'Active' | 'Resolved' | 'Reviewed'>('All');

  const filtered =
    filter === 'All' ? stopWorkAuthorities : stopWorkAuthorities.filter((s) => s.status === filter);

  function openCreate() {
    setForm(emptyForm());
    setEditingId(null);
    setShowForm(true);
  }

  function openEdit(record: StopWorkAuthority) {
    setForm({
      date: record.date,
      initiatedBy: record.initiatedBy,
      location: record.location,
      reason: record.reason,
      description: record.description,
      department: record.department,
      status: record.status,
      resolvedDate: record.resolvedDate,
      resolution: record.resolution,
    });
    setEditingId(record.id);
    setShowForm(true);
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (editingId) {
      dispatch({
        type: 'EDIT_STOP_WORK',
        payload: {
          ...form,
          id: editingId,
          createdAt: stopWorkAuthorities.find((r) => r.id === editingId)!.createdAt,
        },
      });
    } else {
      dispatch({
        type: 'ADD_STOP_WORK',
        payload: { ...form, id: crypto.randomUUID(), createdAt: new Date().toISOString() },
      });
    }
    setShowForm(false);
  }

  function handleDelete(id: string) {
    if (confirm('Are you sure you want to delete this Stop Work Authority record?')) {
      dispatch({ type: 'DELETE_STOP_WORK', payload: id });
    }
  }

  const statusColors: Record<string, string> = {
    Active: 'bg-rose-50 text-rose-600 border-rose-200',
    Resolved: 'bg-emerald-50 text-emerald-600 border-emerald-200',
    Reviewed: 'bg-blue-50 text-blue-600 border-blue-200',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900">Stop Work Authority</h2>
          <p className="mt-1 text-sm text-slate-500">Track and manage stop work actions</p>
        </div>
        <button
          onClick={openCreate}
          className="flex items-center gap-2 rounded-lg bg-rose-500 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition-all hover:bg-rose-600"
        >
          <Plus size={18} />
          New SWA
        </button>
      </div>

      <div className="flex gap-2">
        {(['All', 'Active', 'Resolved', 'Reviewed'] as const).map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`rounded-lg px-4 py-1.5 text-sm font-medium transition-all ${
              filter === s
                ? 'bg-rose-500 text-white shadow-sm'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
        {filtered.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50">
                  <th className="px-4 py-3 font-semibold text-slate-600">Date</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Initiated By</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Location</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Reason</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Department</th>
                  <th className="px-4 py-3 font-semibold text-slate-600">Status</th>
                  {isAdmin && <th className="px-4 py-3 font-semibold text-slate-600">Actions</th>}
                </tr>
              </thead>
              <tbody>
                {filtered.map((swa) => (
                  <tr key={swa.id} className="border-b border-slate-50 transition-colors hover:bg-slate-50">
                    <td className="px-4 py-3 text-slate-700">{swa.date}</td>
                    <td className="px-4 py-3 font-medium text-slate-900">{swa.initiatedBy}</td>
                    <td className="px-4 py-3 text-slate-700">{swa.location}</td>
                    <td className="max-w-[200px] truncate px-4 py-3 text-slate-700">{swa.reason}</td>
                    <td className="px-4 py-3 text-slate-700">{swa.department}</td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-block rounded-full border px-2.5 py-0.5 text-xs font-medium ${statusColors[swa.status]}`}
                      >
                        {swa.status}
                      </span>
                    </td>
                    {isAdmin && (
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => openEdit(swa)}
                            className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-slate-100 hover:text-blue-600"
                          >
                            <Edit3 size={16} />
                          </button>
                          <button
                            onClick={() => handleDelete(swa.id)}
                            className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <ShieldAlert size={48} className="mb-3 text-slate-300" />
            <p className="text-sm font-medium text-slate-400">No Stop Work records</p>
            <p className="text-xs text-slate-300">Create a Stop Work Authority record</p>
          </div>
        )}
      </div>

      {/* Form Modal */}
      <Modal
        isOpen={showForm}
        onClose={() => setShowForm(false)}
        title={editingId ? 'Edit Stop Work' : 'New Stop Work Authority'}
        size="lg"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Date
              </label>
              <input
                type="date"
                required
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-rose-400 focus:outline-none focus:ring-2 focus:ring-rose-100"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Initiated By
              </label>
              <input
                type="text"
                required
                placeholder="Full name"
                value={form.initiatedBy}
                onChange={(e) => setForm({ ...form, initiatedBy: e.target.value })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-rose-400 focus:outline-none focus:ring-2 focus:ring-rose-100"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Location
              </label>
              <input
                type="text"
                required
                placeholder="e.g., Zone 4, Platform B"
                value={form.location}
                onChange={(e) => setForm({ ...form, location: e.target.value })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-rose-400 focus:outline-none focus:ring-2 focus:ring-rose-100"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Department
              </label>
              <input
                type="text"
                required
                placeholder="e.g., Maintenance"
                value={form.department}
                onChange={(e) => setForm({ ...form, department: e.target.value })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-rose-400 focus:outline-none focus:ring-2 focus:ring-rose-100"
              />
            </div>
          </div>

          <div>
            <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
              Reason
            </label>
            <input
              type="text"
              required
              placeholder="Brief reason for stop work"
              value={form.reason}
              onChange={(e) => setForm({ ...form, reason: e.target.value })}
              className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-rose-400 focus:outline-none focus:ring-2 focus:ring-rose-100"
            />
          </div>

          <div>
            <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
              Description
            </label>
            <textarea
              rows={3}
              required
              placeholder="Detailed description of the stop work situation"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-rose-400 focus:outline-none focus:ring-2 focus:ring-rose-100"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Status
              </label>
              <select
                value={form.status}
                onChange={(e) => setForm({ ...form, status: e.target.value as any })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-rose-400 focus:outline-none focus:ring-2 focus:ring-rose-100"
              >
                <option value="Active">Active</option>
                <option value="Resolved">Resolved</option>
                <option value="Reviewed">Reviewed</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Resolved Date
              </label>
              <input
                type="date"
                value={form.resolvedDate}
                onChange={(e) => setForm({ ...form, resolvedDate: e.target.value })}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-rose-400 focus:outline-none focus:ring-2 focus:ring-rose-100"
              />
            </div>
          </div>

          <div>
            <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
              Resolution Notes
            </label>
            <textarea
              rows={2}
              value={form.resolution}
              onChange={(e) => setForm({ ...form, resolution: e.target.value })}
              placeholder="How was this resolved?"
              className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-rose-400 focus:outline-none focus:ring-2 focus:ring-rose-100"
            />
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-600 transition-colors hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-lg bg-rose-500 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-rose-600"
            >
              {editingId ? 'Update' : 'Create'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
